help_me() {
  true
}

failing_helper() {
  false
}
