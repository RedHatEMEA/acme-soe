/* Copyright 2009, CORAID, Inc., and licensed under GPL v.2. */
int dial(char *eth);
int getea(int s, char *name, uchar *ea);

